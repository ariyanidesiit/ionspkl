<?php
//jangan lupa untuk include koneksi
include 'koneksi.php'; //digunakan untuk memanggil koneksi yang udah di buat
//koneksi.php berisi script untuk mengkoneksikan dengan database 

//bikin kondisi dulu,dicek dulu formnya pake metod post apa enggak
if ($_SERVER['REQUEST_METHOD'] == 'POST') { //kondisi, memeriksa apakah metodnya post, kalau iya methodnya post maka jalankan,
    $email = $_POST['email']; //var email yang mengambil nilai / name email / identifier 
    $password = $_POST['password']; //ambil password //ini disesuain sama identifier yang dibikin di form login.html
//intinya -> kalau formulir dikirim pakek metode post,dan ada input email & password, maka var email sama password akan berisi nllai yang diisi pengguna
    
    //bikin statement sql,ini buat ngambil id,password,email dari tabel data regis
    //mari kita preteli script dibawah ini,

        //$conn -> var buat nyimpen objek koneksi database
        //prepare -> sebuah metode buat mempersiapkan pernyataan sql digunain buat eksekusi query di dalam db
    $sql = $conn->prepare("SELECT id, password FROM data_regis WHERE email=?");
        //select -> ambil id,pw,email dari tabel regis
        //kenapa email = ?, buat seleksi (filtering)
    $sql->bind_param("s", $email);
        //buat mengaitkan nilai parameter dan jenis data 
        // kenapa pake s? karena pake string / tipe dataya string
        // s -> string
        // i -> integer
        // d -> double / desimal

    $sql->execute();//di eksekusi / perintah eksekusi
    $result = $sql->get_result();// dapetin hasilnya (hasil dari eksekusi)

    if ($result->num_rows > 0) {//kalau resultnya >0 (lebih dari 0), 
        $row = $result->fetch_assoc();//digunakan buat verifikasi kata sandi
        $hashed_password = $row['password'];//verifikasi kata sandi dari pengguna 

        if (password_verify($password, $hashed_password)) {//membandingkan kata sandi yang dimasukkan oleh pengguna dengan kata sandi yang di-hash yang diambil dari hasil query. Jika kedua kata sandi cocok, itu berarti login berhasil.
            // kalau Login berhasil
            session_start();//sesi dimulai 
            $_SESSION['id'] = $row['id'];
            header('Location: index.html'); // setelah login berhasil halaman mana yang akan di tampilkan
            exit();//ini buat nge stop kalau pengguna udah diarahin ke halaman login
        } else { //ini kalau gak cocok sama kondisi diatas atau sandinya salah, maka jalankan password salah 
            echo "Password salah";
        }
    } else { //ini juga
        echo "Email tidak ditemukan";
    }

    $sql->close();//nutup koneksi / stop koneksi sql
}

$conn->close();//nutup koneksi ke db
?>



